""" ifupdown2 package.

.. moduleauthor:: Roopa Prabhu <roopa@cumulusnetworks.com>

"""
