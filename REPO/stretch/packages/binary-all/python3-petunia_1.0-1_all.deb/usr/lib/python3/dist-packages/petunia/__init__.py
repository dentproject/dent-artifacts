"""__init__.py

module init for TcPersist
"""
